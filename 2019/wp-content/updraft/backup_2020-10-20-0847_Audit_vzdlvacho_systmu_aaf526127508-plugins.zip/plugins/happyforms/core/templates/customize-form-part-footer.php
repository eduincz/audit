		</div>
		<div class="happyforms-widget-actions">
			<a href="#" class="happyforms-form-part-remove"><?php _e( 'Delete', 'happyforms' ); ?></a> |
			<a href="#" class="happyforms-form-part-duplicate"><?php _e( 'Duplicate', 'happyforms' ); ?></a>
			<a href="#" class="happyforms-form-part-advanced-settings"><?php _e( 'More', 'happyforms' ); ?></a>
			<a href="#" class="happyforms-form-part-logic"><?php _e( 'Logic', 'happyforms' ); ?></a>
		</div>
	</div>
</div>
