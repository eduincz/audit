<div class="happyforms-setup-logic-wrap">
	<div class="happyforms-logic-view">
		<a href="https://happyforms.me/upgrade" class="external" target="_blank"><?php _e( 'Upgrade to add logic rule', 'happyforms' ); ?></a>
	</div>
</div>
