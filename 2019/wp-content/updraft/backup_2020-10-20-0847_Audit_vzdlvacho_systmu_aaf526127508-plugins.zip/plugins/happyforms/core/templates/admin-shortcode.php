<script type="text/html" id="tmpl-happyforms-shortcode">
<div class="loading-placeholder">
    <div style="text-align: center">
        <span>{{ data.title }} HappyForms</span>
    </div>
</div>
<span class="wpview-end"></span>
</script>