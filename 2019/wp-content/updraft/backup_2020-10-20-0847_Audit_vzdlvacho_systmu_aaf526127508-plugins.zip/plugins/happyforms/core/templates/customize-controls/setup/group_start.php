<section class="customize-control-group happyforms-nested-settings" data-trigger="<?php echo $control['trigger']; ?>">
