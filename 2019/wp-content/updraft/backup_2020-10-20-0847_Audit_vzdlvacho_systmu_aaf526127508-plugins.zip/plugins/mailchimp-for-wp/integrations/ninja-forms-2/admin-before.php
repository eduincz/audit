<p>
	<?php echo __( 'To integrate with Ninja Forms, add the "Mailchimp" field to your Ninja Forms forms.', 'mailchimp-for-wp' ); ?>
</p>
