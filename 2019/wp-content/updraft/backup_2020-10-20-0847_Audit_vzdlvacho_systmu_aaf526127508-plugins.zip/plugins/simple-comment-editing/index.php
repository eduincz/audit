<?php
/*
Plugin Name: Simple Comment Editing
Plugin URI: http://wordpress.org/extend/plugins/simple-comment-editing/
Description: Simple comment editing for your users.
Author: Ronald Huereca
Version: 2.5.1
Requires at least: 5.0
Author URI: https://mediaron.com
Contributors: ronalfy
Text Domain: simple-comment-editing
Domain Path: /languages
*/
define( 'SCE_SLUG', plugin_basename(__FILE__) );
require( 'simple-comment-editing.php' );